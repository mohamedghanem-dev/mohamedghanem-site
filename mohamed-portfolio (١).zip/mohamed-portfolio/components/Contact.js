export default function Contact() {
  return (
    <section id="contact" className="py-20 px-4 md:px-20 bg-gray-900 text-white">
      <h2 className="text-4xl font-bold mb-6 text-center">Contact Me</h2>
      <form className="max-w-xl mx-auto mt-8 space-y-6">
        <input type="text" placeholder="Name" className="w-full p-4 rounded-lg bg-gray-800 border border-gray-700 text-white" />
        <input type="email" placeholder="Email" className="w-full p-4 rounded-lg bg-gray-800 border border-gray-700 text-white" />
        <textarea placeholder="Message" rows="5" className="w-full p-4 rounded-lg bg-gray-800 border border-gray-700 text-white" />
        <button type="submit" className="w-full bg-purple-700 py-3 rounded-lg font-semibold hover:bg-purple-600 transition">Send Message</button>
      </form>
    </section>
  );
}