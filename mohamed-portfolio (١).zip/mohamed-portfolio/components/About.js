export default function About() {
  return (
    <section id="about" className="py-20 px-4 md:px-20 bg-gray-800 text-white">
      <h2 className="text-4xl font-bold mb-6 text-center">About Me</h2>
      <p className="max-w-2xl mx-auto text-center opacity-70 leading-relaxed">
        I'm Mohamed Ganem, a Full Stack Developer passionate about building modern web applications with React, Next.js, and Node.js.
      </p>
    </section>
  );
}