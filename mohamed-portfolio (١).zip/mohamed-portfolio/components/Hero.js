import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center bg-gradient-to-br from-purple-900 via-purple-800 to-purple-700">
      <motion.h1 initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="text-5xl md:text-7xl font-bold text-white">Mohamed Ganem</motion.h1>
      <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.5 }} className="text-xl md:text-2xl mt-4 text-white">Full Stack Developer</motion.p>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 1 }} className="mt-6 flex space-x-4">
        <a href="#projects" className="bg-white text-purple-800 px-6 py-3 rounded-lg font-semibold hover:bg-purple-200 transition">View Projects</a>
        <a href="#contact" className="bg-purple-700 px-6 py-3 rounded-lg font-semibold hover:bg-purple-600 transition">Contact Me</a>
      </motion.div>
    </section>
  );
}