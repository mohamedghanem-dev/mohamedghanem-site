import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="fixed w-full bg-gray-900 z-50 p-4 flex justify-between items-center">
      <h1 className="text-white font-bold text-xl">Mohamed Ganem</h1>
      <div className="space-x-6">
        <Link href="#about" className="text-gray-300 hover:text-purple-400">About</Link>
        <Link href="#skills" className="text-gray-300 hover:text-purple-400">Skills</Link>
        <Link href="#projects" className="text-gray-300 hover:text-purple-400">Projects</Link>
        <Link href="#contact" className="text-gray-300 hover:text-purple-400">Contact</Link>
      </div>
    </nav>
  );
}