export default function Skills() {
  const skills = ['React', 'Next.js', 'Node.js', 'Tailwind CSS', 'Framer Motion'];
  return (
    <section id="skills" className="py-20 px-4 md:px-20 bg-gray-900 text-white">
      <h2 className="text-4xl font-bold mb-6 text-center">Skills</h2>
      <div className="flex flex-wrap justify-center gap-6 mt-8">
        {skills.map((skill, i) => (
          <div key={i} className="bg-gray-700 px-6 py-3 rounded-lg">{skill}</div>
        ))}
      </div>
    </section>
  );
}