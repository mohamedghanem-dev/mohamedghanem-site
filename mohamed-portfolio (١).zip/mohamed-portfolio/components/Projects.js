export default function Projects() {
  const projects = [
    { title: 'Project One', link: '#' },
    { title: 'Project Two', link: '#' },
    { title: 'Project Three', link: '#' },
  ];

  return (
    <section id="projects" className="py-20 px-4 md:px-20 bg-gray-800 text-white">
      <h2 className="text-4xl font-bold mb-6 text-center">Projects</h2>
      <div className="grid md:grid-cols-3 gap-8 mt-8">
        {projects.map((p, i) => (
          <div key={i} className="bg-gray-700 p-6 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">{p.title}</h3>
            <a href={p.link} className="text-purple-400 hover:underline">View Project</a>
          </div>
        ))}
      </div>
    </section>
  );
}